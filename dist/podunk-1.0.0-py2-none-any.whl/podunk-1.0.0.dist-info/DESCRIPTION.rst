Reporte personalizado para Odoo.
Mas informacion en : http://www.github.com/manexware


