Reporte personalizado para Odoo.
Mas informacinon en : http://www.github.com/manexware


