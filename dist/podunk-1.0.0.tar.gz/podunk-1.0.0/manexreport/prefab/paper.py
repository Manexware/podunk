#------------------------------------------------------------------------------
#   file:       podunk/prefab/paper.py
#   author:     Jim Storch
#------------------------------------------------------------------------------

LETTER_PORTRAIT = (612, 792)
LETTER_LANDSCAPE = (792, 612)
LEGAL_PORTRAIT = (612, 1008)
LEGAL_LANDSCAPE = (1008, 612)
A4_PORTRAIT = (595, 842)
A4_LANDSCAPE = (842, 595)