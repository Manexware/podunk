from distutils.core import setup

setup(
    name='podunk',
    version='1.0.0',
    packages=['manexreport', 'manexreport.prefab', 'manexreport.widget', 'manexreport.project'],
    url='http://www.github.com/manexware',
    license='GPLv3',
    author='mevu',
    author_email='manuel.vega@manexware.com',
    description=''
)
